from django.db import models
from django.contrib.auth.models import User


class Event(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    location = models.CharField(max_length=200)
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()
    capacity = models.PositiveIntegerField(
        default=0, help_text="0 means unlimited capacity"
    )
    organizer = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name="organized_events",
        null=True, blank=True
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["start_time"]

    def __str__(self):
        return self.title

    @property
    def registration_count(self):
        return self.registrations.filter(status="confirmed").count()

    @property
    def is_full(self):
        if self.capacity == 0:
            return False
        return self.registration_count >= self.capacity

    @property
    def spots_left(self):
        if self.capacity == 0:
            return None
        return max(self.capacity - self.registration_count, 0)


class Registration(models.Model):
    STATUS_CHOICES = [
        ("confirmed", "Confirmed"),
        ("cancelled", "Cancelled"),
    ]

    event = models.ForeignKey(
        Event, on_delete=models.CASCADE, related_name="registrations"
    )
    user = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name="registrations"
    )
    status = models.CharField(
        max_length=10, choices=STATUS_CHOICES, default="confirmed"
    )
    registered_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("event", "user")
        ordering = ["-registered_at"]

    def __str__(self):
        return f"{self.user.username} -> {self.event.title} ({self.status})"
