from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register(r"events", views.EventViewSet, basename="event")
router.register(r"registrations", views.RegistrationViewSet, basename="registration")
router.register(r"signup", views.SignupView, basename="signup")

urlpatterns = [
    path("", views.index, name="index"),
    path("api/", include(router.urls)),
    path("api/login/", views.login_view, name="login"),
    path("api/logout/", views.logout_view, name="logout"),
    path("api/me/", views.current_user_view, name="current_user"),
]
