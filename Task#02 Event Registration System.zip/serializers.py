from django.contrib.auth.models import User
from rest_framework import serializers
from .models import Event, Registration


class EventListSerializer(serializers.ModelSerializer):
    organizer_name = serializers.CharField(
        source="organizer.username", read_only=True, default=None
    )

    class Meta:
        model = Event
        fields = [
            "id", "title", "location", "start_time", "end_time",
            "capacity", "registration_count", "is_full", "spots_left",
            "organizer_name",
        ]


class EventDetailSerializer(serializers.ModelSerializer):
    organizer_name = serializers.CharField(
        source="organizer.username", read_only=True, default=None
    )

    class Meta:
        model = Event
        fields = [
            "id", "title", "description", "location", "start_time",
            "end_time", "capacity", "registration_count", "is_full",
            "spots_left", "organizer_name", "created_at",
        ]


class EventWriteSerializer(serializers.ModelSerializer):
    class Meta:
        model = Event
        fields = [
            "id", "title", "description", "location", "start_time",
            "end_time", "capacity",
        ]


class RegistrationSerializer(serializers.ModelSerializer):
    event_title = serializers.CharField(source="event.title", read_only=True)
    username = serializers.CharField(source="user.username", read_only=True)

    class Meta:
        model = Registration
        fields = [
            "id", "event", "event_title", "user", "username",
            "status", "registered_at",
        ]
        read_only_fields = ["user", "status", "registered_at"]


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ["id", "username", "email"]
