from rest_framework import viewsets, status, permissions
from rest_framework.decorators import action, api_view, permission_classes
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, IsAuthenticatedOrReadOnly, AllowAny
from django.shortcuts import render
from django.contrib.auth.models import User
from django.contrib.auth import login, logout, authenticate
from django.db import IntegrityError

from .models import Event, Registration
from .serializers import (
    EventListSerializer,
    EventDetailSerializer,
    EventWriteSerializer,
    RegistrationSerializer,
    UserSerializer,
)


def index(request):
    """Renders the single-page frontend."""
    return render(request, "events/index.html")


class IsOrganizerOrReadOnly(permissions.BasePermission):
    """Only the event's organizer (or staff) can edit/delete it."""

    def has_object_permission(self, request, view, obj):
        if request.method in permissions.SAFE_METHODS:
            return True
        return request.user.is_staff or obj.organizer_id == request.user.id


class EventViewSet(viewsets.ModelViewSet):
    """
    list   -> GET /api/events/
    detail -> GET /api/events/{id}/
    create -> POST /api/events/        (organizers / staff)
    update -> PUT/PATCH /api/events/{id}/
    delete -> DELETE /api/events/{id}/
    """

    queryset = Event.objects.all()
    permission_classes = [IsAuthenticatedOrReadOnly, IsOrganizerOrReadOnly]

    def get_serializer_class(self):
        if self.action == "list":
            return EventListSerializer
        if self.action in ("create", "update", "partial_update"):
            return EventWriteSerializer
        return EventDetailSerializer

    def perform_create(self, serializer):
        serializer.save(organizer=self.request.user)

    @action(detail=True, methods=["post"], permission_classes=[IsAuthenticated])
    def register(self, request, pk=None):
        """POST /api/events/{id}/register/ -> register the current user."""
        event = self.get_object()

        existing = Registration.objects.filter(event=event, user=request.user).first()
        if existing:
            if existing.status == "confirmed":
                return Response(
                    {"detail": "You are already registered for this event."},
                    status=status.HTTP_400_BAD_REQUEST,
                )
            existing.status = "confirmed"
            existing.save()
            serializer = RegistrationSerializer(existing)
            return Response(serializer.data, status=status.HTTP_200_OK)

        if event.is_full:
            return Response(
                {"detail": "This event is full."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        try:
            registration = Registration.objects.create(event=event, user=request.user)
        except IntegrityError:
            return Response(
                {"detail": "You are already registered for this event."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        serializer = RegistrationSerializer(registration)
        return Response(serializer.data, status=status.HTTP_201_CREATED)


class RegistrationViewSet(viewsets.ModelViewSet):
    """
    list   -> GET /api/registrations/        (only the current user's registrations)
    delete -> DELETE /api/registrations/{id}/ (cancel)
    """

    serializer_class = RegistrationSerializer
    permission_classes = [IsAuthenticated]
    http_method_names = ["get", "post", "delete", "head", "options"]

    def get_queryset(self):
        return Registration.objects.filter(user=self.request.user)

    def destroy(self, request, *args, **kwargs):
        """Cancelling a registration sets status to 'cancelled' instead of deleting,
        so event history / capacity counts stay accurate."""
        instance = self.get_object()
        instance.status = "cancelled"
        instance.save()
        serializer = self.get_serializer(instance)
        return Response(serializer.data, status=status.HTTP_200_OK)


class SignupView(viewsets.ViewSet):
    """POST /api/signup/ -> create a new user account and log them in."""

    permission_classes = [permissions.AllowAny]

    def create(self, request):
        username = request.data.get("username", "").strip()
        password = request.data.get("password", "")
        email = request.data.get("email", "").strip()

        if not username or not password:
            return Response(
                {"detail": "Username and password are required."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        if User.objects.filter(username=username).exists():
            return Response(
                {"detail": "That username is already taken."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        user = User.objects.create_user(username=username, password=password, email=email)
        login(request, user)
        return Response(UserSerializer(user).data, status=status.HTTP_201_CREATED)


@api_view(["POST"])
@permission_classes([AllowAny])
def login_view(request):
    """POST /api/login/ -> {username, password}"""
    username = request.data.get("username", "")
    password = request.data.get("password", "")
    user = authenticate(request, username=username, password=password)
    if user is None:
        return Response({"detail": "Invalid credentials."}, status=status.HTTP_400_BAD_REQUEST)
    login(request, user)
    return Response(UserSerializer(user).data)


@api_view(["POST"])
@permission_classes([IsAuthenticated])
def logout_view(request):
    logout(request)
    return Response({"detail": "Logged out."})


@api_view(["GET"])
@permission_classes([AllowAny])
def current_user_view(request):
    if request.user.is_authenticated:
        return Response(UserSerializer(request.user).data)
    return Response({"detail": "Not authenticated."}, status=status.HTTP_401_UNAUTHORIZED)
