# Event Registration System (Django + DRF)

## Setup
pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser   # for the admin panel
python manage.py runserver

Open http://localhost:8000 for the app, http://localhost:8000/admin/ for the admin panel.

## Models
- **Event**: title, description, location, start_time, end_time, capacity (0 = unlimited), organizer (FK to User)
- **Registration**: links a User to an Event with a status (confirmed/cancelled). One active registration per user per event (unique_together).

## API Endpoints
- `GET  /api/events/`               - list all events (with spots left / full status)
- `POST /api/events/`               - create an event (logged in users only; becomes organizer)
- `GET  /api/events/<id>/`          - event details
- `PUT/PATCH /api/events/<id>/`     - edit event (organizer or staff only)
- `DELETE /api/events/<id>/`        - delete event (organizer or staff only)
- `POST /api/events/<id>/register/` - register the current user for the event (rejects if full)
- `GET  /api/registrations/`        - list the logged-in user's own registrations
- `DELETE /api/registrations/<id>/` - cancel a registration (soft-cancel, keeps history)
- `POST /api/signup/`               - create an account (auto logs in)
- `POST /api/login/`                - log in
- `POST /api/logout/`               - log out
- `GET  /api/me/`                   - current logged-in user

## Frontend
A single-page UI at `/` (vanilla JS) covering: browsing events, signing up/logging in,
registering/cancelling, and creating events. Session-based auth via Django's built-in
auth system, CSRF token read from cookies for POST/DELETE requests.

## Admin Panel
Full Django admin at `/admin/` — manage events and registrations, see registrations
inline under each event. Create an account with `createsuperuser` to access it.

## Notes
- Capacity enforcement happens server-side in the `register` action.
- Cancelling a registration sets its status to "cancelled" rather than deleting the row,
  so event history and re-registration both work cleanly.
- Default DB is SQLite (db.sqlite3, created by `migrate`). Swap to PostgreSQL by changing
  `DATABASES` in eventreg/settings.py.
